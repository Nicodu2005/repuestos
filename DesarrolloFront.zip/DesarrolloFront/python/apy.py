from flask import Flask, request, jsonify
import mysql.connector
 
from flask_cors import CORS
 
app = Flask(__name__)
CORS(app)
 
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Asegúrate de que la contraseña esté correcta
    database="repuestos"  # Cambié el punto por guion bajo en el nombre de la base de datos
)
 
cursor = db.cursor(dictionary=True)


@app.route('/tuspedidos', methods=['GET'])
def verPedido():
    try:
        # Obtener el customer_id desde los parámetros de la consulta
        customer_id = request.args.get('customer_id')

        # Validar que el customer_id esté presente
        if not customer_id:
            return jsonify({'message': 'Falta el ID del cliente'}), 400

        # Ejecutar la consulta SQL para obtener los pedidos
        cursor.execute("SELECT oi.id, oi.order_id, oi.product_id, p.name, p.description, p.price, p.stock, p.image, oi.quantity, oi.price FROM order_items oi INNER JOIN products p ON oi.product_id = p.id INNER JOIN orders o ON oi.order_id = o.id WHERE o.customer_id = %s", (customer_id,))
        
        # Obtener todos los resultados
        orders = cursor.fetchall()

        # Devolver los resultados
        return jsonify(orders), 200

    except Exception as e:
        # Manejar cualquier error que ocurra durante la consulta
        print(f"Error al obtener los pedidos: {e}")
        return jsonify({'message': 'Hubo un error al obtener los pedidos'}), 500

@app.route('/guardar-pedido', methods=['POST'])
def guardar_pedido():
    try:
        # Obtener los datos del pedido desde el cuerpo de la solicitud
        pedido = request.get_json()  # Recibimos los datos en formato JSON
        items = pedido['items']  # Productos en el carrito
        total = pedido['total']  # Total del carrito
        fecha = pedido['fecha']  # Fecha del pedido
        idCustomer = pedido['customer_id']
        status = pedido.get('status', 'pendiente')  # Obtener el status, por defecto es "pendiente"

        # Validación de los datos
        if not items or not total or not fecha:
            return jsonify({'message': 'Faltan datos del pedido'}), 400
        
        print("Items recibido:", items)
        print("Total recibido:", total)
        print("fecha recibido:", fecha)
        print("status recibido:", status)
        print("customer_id recibido:", idCustomer)

        # Verificar el stock de los productos antes de proceder
        for item in items:
            cursor.execute("SELECT stock FROM products WHERE id = %s", (item['productId'],))
            producto = cursor.fetchone()
            if not producto or producto['stock'] < item['quantity']:
                return jsonify({'message': f'No hay suficiente stock para el producto ID {item["productId"]}'}), 400

        # Insertar el pedido en la tabla "orders"
        cursor.execute("INSERT INTO orders (order_date, status, total, customer_id) VALUES (%s, %s, %s, %s)", 
                       (fecha, status, total, idCustomer))
        db.commit()

        # Obtener el ID del pedido recién insertado
        order_id = cursor.lastrowid
        print(f"ID del pedido insertado: {order_id}")

        # Insertar los productos del pedido en la tabla "order_items"
        for item in items:
            print(f"Insertando producto con ID: {item['productId']} y cantidad: {item['quantity']}")
            cursor.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (%s, %s, %s, %s)", 
                           (order_id, item['productId'], item['quantity'], item['price']))
            
            # Actualizar el stock de los productos en la tabla "products"
            cursor.execute("UPDATE products SET stock = stock - %s WHERE id = %s", 
                           (item['quantity'], item['productId']))
        
        # Confirmar todos los cambios en la base de datos
        db.commit()

        return jsonify({'success': True, 'message': 'Pedido realizado con éxito'}), 200

    except Exception as e:
        # Imprimir el error completo para depuración
        print(f"Error al guardar el pedido: {e}")
        db.rollback()  # Deshacer cualquier cambio en caso de error
        return jsonify({'success': False, 'message': 'Hubo un error al guardar el pedido', 'error': str(e)}), 500

#REGISTRARSE
@app.route('/registrarse', methods=['POST'])
def registrarse():

    data = request.json

#     variables optenidas del front
    print("la data es",data)
    name= data.get('name')
    phone = data.get('phone')
    address= data.get('address')
    email = data.get('email')
    password = data.get('password')

    print("Name recibido:", name)
    print("phone recibido:", phone)
    print("address recibido:", address)
    print("Email recibido:", email)
    print("Password recibido:", password)

     # valida los campos que no falten datos
    if not email or not password or not name or not phone or not address:
        return jsonify({'message': 'Faltan datos del usuario'}), 400
    cursor.execute("insert into customers (name,phone,email,password,address) values (%s,%s,%s,%s,%s);",(name, phone, email, password, address))
    db.commit()
    return jsonify({'message': 'Usuario registrado exitosamente'}), 201

@app.route('/login', methods=['POST'])
def login():

    data = request.json

    print("la data es",data)
    email = data.get('email')
    password = data.get('password')
   
    print("Email recibido:", email)
    print("Password recibido:", password)
 
    if not email or not password:
        return jsonify({'message': 'Faltan datos del usuario'}), 400
 
    # Ejecuta la consulta para buscar el usuario
    cursor.execute("SELECT * FROM customers WHERE email = %s AND password = %s", (email, password))
    user = cursor.fetchone()
 
    # Imprime el resultado de la consulta para depuración
    print("Resultado de la consulta:", user)
 
    if user:
        return jsonify({'message': 'Inicio de sesión exitoso', 'user': user}), 200
    else:
        return jsonify({'message': 'Credenciales incorrectas'}), 401

@app.route('/products', methods=['GET'])
def get_products():
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    return jsonify(products), 200
 
 
if __name__ == '__main__':
    app.run(debug=True)