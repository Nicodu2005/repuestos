new Vue({
    el:'#app',
    data:{
        productos:[],
        url_productos: "http://127.0.0.1:5000/products",
        loginText:"Iniciar Sesión"
    },
    methods:{
        async cargarProductos(){
            try{
                const response = await fetch(this.url_productos);
                if(response.ok){
                    const productos = await response.json();
                    this.productos = productos.slice(-10).reverse();
                }
            }catch(e){
                console.log('error al cargar productos',error);
            }
        },
        toggleLogin(){
            if (this.loginText === "cerrar Sesión"){
                localStorage.removeItem("isLoggedIn");
                this.loginText="iniciar Sesión";
            }else{
                window.location.herf="main.html";
            }
        }
    },
        created(){
            this.cargarProductos();
            this.loginText=localStorage.getItem("isLoggedIn")? "cerrar sesion" : "iniciar Sesion";
        }
    
});