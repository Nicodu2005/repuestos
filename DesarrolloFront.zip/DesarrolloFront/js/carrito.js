

const STORE_KEY = 'cartItems';
const store = new Vuex.Store({
    state: {
        cart: JSON.parse(localStorage.getItem(STORE_KEY)) || [] // Cargar el estado inicial desde localStorage
    },
    mutations: {
        add_to_cart(state, producto) {
            // Verificar si el producto ya existe en el carrito
            const existingItem = state.cart.find(item => item.cartId === producto.id);

            if (existingItem) {
                // Si el producto ya está en el carrito, solo incrementar la cantidad
                existingItem.quantity += 1;
            } else {
                // Si el producto no está, agregarlo al carrito con cantidad 1
                const cartItem = {
                    ...producto,
                    cartId: producto.id,
                    quantity: 1 // Inicializar la cantidad
                };
                state.cart.push(cartItem);
            }
           
            localStorage.setItem(STORE_KEY, JSON.stringify(state.cart)); // Guardar en localStorage
        },
        remove_to_cart(state, producto) {
            const item = state.cart.find(item => item.cartId === producto.cartId);

            if (item) {
                // Si la cantidad es mayor que 1, decrementamos la cantidad
                if (item.quantity > 1) {
                    item.quantity -= 1;
                } else {
                    // Si la cantidad es 1, eliminamos el producto del carrito
                    state.cart = state.cart.filter(item => item.cartId !== producto.cartId);
                }
            }

            // Actualizar localStorage después de la modificación
            localStorage.setItem(STORE_KEY, JSON.stringify(state.cart));
        },
        clear_cart(state) {
            state.cart = [];
            localStorage.removeItem(STORE_KEY); // Limpiar localStorage
        }
    },
    getters: {
        cart: state => state.cart,
        cartTotal: state => state.cart.reduce((total, producto) => total + producto.price * producto.quantity, 0) // Calcular total considerando la cantidad
    }
});

new Vue({
    el: '#app',
    store,
    data: {
        ordenes:[],
        productos: [],
        busqueda: '',
        counterCart: 0,
        url_productos: "http://127.0.0.1:5000/products",
        apiURL: "http://127.0.0.1:5000//guardar-pedido",
        apiURLorder: "http://127.0.0.1:5000/tuspedidos",
        apiitems:"http://127.0.0.1:5000/items",
        selectedCategories: "todas",
        selectedOrder:'Todos'
    },
 mounted() {
    
    
        // Imprimir el contenido de localStorage cuando el componente se haya montado
        console.log("Contenido de localStorage:", localStorage);

        // Si quieres ver específicamente 'customer_id':

        console.log("Valor de customer_id en localStorage:", localStorage.getItem('customer_id'));
        
        // Si deseas verificar si el usuario está logueado:
        console.log("Estado de isLoggedIn:", localStorage.getItem("isLoggedIn"));
 },
    computed: {
        idOrder(){
            const idOr = this.ordenes.map(orden => orden.order_id);
            return [...new Set(idOr)];
            
        },
        ordersFiltrados() {
            if (this.selectedOrder === 'Todos') {
                return this.ordenes;
            }
            return this.ordenes.filter(orden => orden.order_id === this.selectedOrder)
        },

        productosFiltrados() {
            if (this.selectedCategories === 'todas') {
                return this.productos.filter(producto => producto.name.toLowerCase().includes(this.busqueda.toLowerCase()));
            } return this.productos.filter(producto => producto.categories === this.selectedCategories && producto.name.toLowerCase().includes(this.busqueda.toLowerCase()));

        },
        uniquecategories() {
            const categories = this.productos.map(producto => producto.categories);
            return [...new Set(categories)];
        },

        cart() {
            return this.$store.getters.cart;
        },
        TotalCart() {
            return this.$store.getters.cartTotal;
        },
    },
    
    methods: {
        async obtenerOrdenes() {
            try {
                const customerId = localStorage.getItem('customer_id');
                // Realizar la solicitud GET para obtener las órdenes
                const response = await axios.get(`${this.apiURLorder}?customer_id=${customerId}`);
                if (response.status === 200) {
                    // Si la respuesta es exitosa, almacenar las órdenes en la variable "ordenes"
                    this.ordenes = response.data;
                }
            } catch (error) {
                console.error('Error al obtener las órdenes:', error);
            }
        },
        async comprar() {
            const customerId = localStorage.getItem('customer_id');
            if (!customerId) {
                alert("Debes iniciar sesión para realizar un pedido.");
                return;
            }
            const pedido = {
                customer_id: customerId,
                items: this.cart.map(item => ({
                    productId: item.cartId,  // ID del producto
                    quantity: item.quantity, // Cantidad del producto
                    price: item.price        // Precio del producto
                })),
                total: this.TotalCart,       // Total del carrito
                fecha: new Date().toISOString(),

                
            };
            try {
                        const response = await axios.post(this.apiURL, pedido);
        
                if (response.data.success) {
                    alert('Pedido realizado con éxito');
                    this.$store.commit('clear_cart'); // Limpiar el carrito
                    window.location.href = 'pasarela.html'; // Redirigir a la página principal o de confirmación
                } else {
                    alert('Hubo un error al realizar el pedido');
                }
            } catch (error) {
                console.error('Error al realizar la compra:', error);
                alert('Hubo un error al realizar la compra. Por favor, inténtalo nuevamente.');
            }
        
        },

        async cargarProductos() {
            try{
            const response = await axios.get(this.url_productos);
        
        if (response.status === 200) {
            // Si la respuesta es exitosa, almacenar los productos
            this.productos = response.data.slice(-20).reverse();
        } 
        else {
            console.log('Error al cargar productos', response.status);
        
            } }catch (e) {
                console.log('error al cargar productos', e);
            }
        },
       
        filterCategories() {
            // La lógica para filtrar se maneja en la propiedad computada
        },
        filterID() {
            // La lógica para filtrar se maneja en la propiedad computada
        },
        // metodo de cargar productos al carrito 
        agregarCarrito(producto) {
            this.$store.commit('add_to_cart', producto);
            alert("se ha agregado al carrito el producto");
            console.log(localStorage.getItem('customer_id'));
        },
        removeFromCart(producto) {
            this.$store.commit('remove_to_cart', producto);
            alert("se ha eliminado un producto del carrito");

        },
        clearCart() {
            this.$store.commit('clear_cart');
            alert("se ha limpiado el carrito");
        },
       

    },
    created() {
        this.cargarProductos();
        this.obtenerOrdenes();
        
    }
});
