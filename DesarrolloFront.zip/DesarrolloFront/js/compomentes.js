Vue.component('nav-menu', {
  template:
    `<header>
  <div class="text-warning bg-dark bg-Emphasis-subtle container-fluid">
    <button class="bg-warning navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" text-warning bg-dark>
      <span class=" navbar-toggler-icon"></span>
    </button>
    <div class="text-warning bg-dark collapse navbar-collapse " id="navbarNav">
      <ul class="navbar-nav" >
        <li class="nav-item">
          <a class="espa text-warning nav-link active" aria-current="page"  href="/main.html#inicio">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="espa text-warning nav-link" href="/main.html#producto">Producto</a>
        </li>
        <li class="nav-item">
          <a class="espa text-warning nav-link" href="/main.html#sobre">Sobre Nosotros</a>
        </li>
        <li class="nav-item">
          <a class="espa text-warning nav-link" href="/main.html#contacto">Contactenos</a>
        </li>
        <li class="nav-item">
          <a class="espa text-warning nav-link" href="/iniciarSesion.html" @click.prevent="toggleLogin">{{loginText}}</a>
        </li>
         <li class="nav-item">
          <a class="espa text-warning nav-link" href="/carrito.html">Carrito</a>
        </li>
        <li class="nav-item">
          <a class="espa text-warning nav-link" href="/tuspedidos.html">Pedidos</a>
        </li>
      </ul>
    </div>
  </div>
  </header>`,
  data() {
    return {
      loginText: 'Iniciar sesión'  // Valor inicial por defecto
    };
  }, methods: {
    toggleLogin() {
      if (this.loginText === "Cerrar Sesión") {
        localStorage.removeItem("isLoggedIn");
        localStorage.setItem('customer_id', null);
        this.loginText = "Iniciar sesión";
        window.location.href = "/iniciarSesion.html";
         
      } else {
        window.location.href = "/iniciarSesion.html";
      }
    }
  },
  created() {
    this.loginText = localStorage.getItem("isLoggedIn") ? "Cerrar Sesión" : "Iniciar sesión";
  }
}),
  Vue.component('footer-personalizado', {

    template: `
    <footer class="text-warning bg-dark" >
    <div class="container text-center text-md-start">
    <div class="row text-center text-md-start">

        <div class="col-md-3  col-lg-3 col-xl-3 mx-auto mt-3">

            <h5 class="text-uppercase mb-4 font-weight-bold " >Nosotros</h5>
            
            <p>Pagina realizada por Nicolas Duran Poveda, utilizo el framework boostrap version 5 atravez de cdn de la pagina oficial </p>
            </div>
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">

            <h5 class="text-uppercase mb-4 font-weight-bold text-warning">contactanos</h5>
            <hr class="mb-4"> 
            <ol class="list-unstyled list-inline">
               <p> <li class="fas fa-print"></li> telefono : 324288732432 </p>
               <p> <li class="fas fa-envelope me-3"></li>correo:nicolasduran@ucompensar.edu.co</p>
               <p><li class="fas fa-home"></li> Direccion: Carrera 5b este #25h-46</p>
            </ol>
        </div>
    </div>
</div>
</footer>`})

new Vue({

});




