new Vue({
    el: '#app',
    data: {
        email:"",
        password:"",
        errorMessage:"",
        apiURL:"http://127.0.0.1:5000/login"
       },
    methods : {
        async handleLogin(){
            localStorage.removeItem('customer_id'); 

            console.log("email " + this.email   , "password"+ this.password );
            
            if(this.email.trim()===""|| this.password.trim()===""){
                this.errorMessage="No se ha podido iniciar sesion, faltan datos";
                return
            }
    
            else{
                try{
                    const response= await axios.post(this.apiURL,{
                        email: this.email,
                        password: this.password
                    });
                    if(response.data.message==='Inicio de sesión exitoso'){
                        localStorage.setItem('customer_id', response.data.user.id);
                        window.location.href="/main.html";
                        localStorage.setItem('isLoggedIn', 'true');
                    } else{
                        this.errorMessage="no se ha podido iniciar sesion, Verifique sus credenciales"
                        console.log(response.data);
                    }
                }catch(error){
                    this.errorMessage ="Usuario o contraseña incorrecta";
                    
                }
            }
        },

}
});