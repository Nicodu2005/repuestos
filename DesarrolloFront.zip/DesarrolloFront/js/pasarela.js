new Vue({
    el: '#app',
    data: {
        cardNumber: '',
        expiryDate: '',
        cvv: '',
        message: '',
        messageType: ''
    },
    methods: {
        procesarPago() {
            // Validar los datos de la tarjeta
            if (this.cardNumber.length !== 16 || isNaN(this.cardNumber)) {
                this.mostrarMensaje("El número de tarjeta no es válido.", "error");
                return;
            }

            if (!this.expiryDate.match(/^\d{2}\/\d{2}$/)) {
                this.mostrarMensaje("La fecha de expiración no es válida.", "error");
                return;
            }

            if (this.cvv.length !== 3 || isNaN(this.cvv)) {
                this.mostrarMensaje("El CVV no es válido.", "error");
                return;
            }

            // Simulamos un pago exitoso si las validaciones son correctas
            this.mostrarMensaje("¡Pago realizado con éxito! Gracias por tu compra.", "success");
            window.location.href="/tuspedidos.html"
        },

        mostrarMensaje(mensaje, tipo) {
            this.message = mensaje;
            this.messageType = tipo;
        }
    }
});