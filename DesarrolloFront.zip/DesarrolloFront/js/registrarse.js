new Vue({

el: '#app',
data: {
    name:'',
    phone:'',
    address:'',
    email:"",
    password:"",
    errorMessage:"",
    apiURL:"http://127.0.0.1:5000/registrarse"
   },
methods : {
    
    async handleRegistrer(){
        
        if(this.email.trim()===""|| this.password.trim()===""|| this.name.trim()===""||this.phone.trim()===""||this.email.trim()===""){
            this.errorMessage="No se ha podido registrarse, faltan datos";
            return
        }else{
            console.log('email '+this.email,'name: '+this.name,'address: '+this.address,'password: '+this.password,'phone: '+this.phone);
            try{
                const response = await axios.post(this.apiURL, {
                    name: this.name,
                    phone: this.phone,
                    address: this.address,
                    email: this.email,
                    password: this.password
                });
                if(response.data.message==='Usuario registrado exitosamente'){

                    window.location.href="/iniciarSesion.html"

                } else{
                    this.errorMessage="no se ha podido registrarse, Verifique sus credenciales"
                    console.log(error);
                }
            }catch(error){
                this.errorMessage ="no se ha podido registrarse"
                console.log(error);
            }
        }

    },

    redireccionLogin(){
       window.location.href="/iniciarSesion.html"

    }

}
});